import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# 1. Cargar los datos del CSV
try:
    df = pd.read_csv('tareas.csv')
except FileNotFoundError:
    print("Error: No se encontró el archivo 'tareas.csv'.")
    exit()

# 2. Limpieza y preparación de datos
df = df.dropna(subset=['Fecha de inicio', 'Fecha de finalización'])

# Le decimos a Pandas que el formato es Día-Mes-Año
df['Inicio'] = pd.to_datetime(df['Fecha de inicio'], dayfirst=True)
df['Fin'] = pd.to_datetime(df['Fecha de finalización'], dayfirst=True)

# Calcular duración en días
df['Duracion'] = (df['Fin'] - df['Inicio']).dt.days + 1

# Ordenar por 'Asunto' para mantener la estructura WBS
df = df.sort_values(by='Asunto', ascending=True)

# ---------------------------------------------------------
# LA MAGIA DEL ESPACIADO: Altura dinámica basada en la cantidad de tareas
num_tareas = len(df)
# Le damos 0.4 pulgadas de altura por cada tarea (mínimo 9 pulgadas)
alto_figura = max(9, num_tareas * 0.33) 
# ---------------------------------------------------------

# 3. Configuración del Gráfico con la nueva altura
fig, ax = plt.subplots(figsize=(14, alto_figura))

# Definir colores profesionales
color_tarea = '#2E7D32'     # Verde para tareas normales
color_resumen = '#37474F'   # Gris oscuro para paquetes (Summary tasks)
color_hito = '#E65100'      # Naranja para los Hitos (Milestones)

# 4. Dibujar las barras y rombos
for index, row in df.iterrows():
    tipo = str(row['Tipo']).lower()
    asunto = row['Asunto']
    inicio = row['Inicio']
    duracion = row['Duracion']
    
    # Lógica para dibujar según el Tipo de tarea
    if 'hito' in tipo or 'milestone' in tipo:
        ax.plot([inicio], [asunto], marker='D', color=color_hito, markersize=10, linestyle='None')
    elif 'resumen' in tipo or 'summary' in tipo or 'epic' in tipo:
        # Barras un poco más delgadas (height=0.5) para que respiren
        ax.barh(asunto, duracion, left=inicio, color=color_resumen, height=0.6)
    else:
        # Barras normales más delgadas (height=0.3)
        ax.barh(asunto, duracion, left=inicio, color=color_tarea, height=0.4)

# 5. Formateo visual
ax.invert_yaxis() # Invertir el eje Y para que la tarea 0.0 quede arriba

# Formatear el eje X (Fechas)
ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=1)) # Una marca por semana
ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b-%Y')) # Formato: 27-Mar-2026
plt.xticks(rotation=45, ha='right')

# Etiquetas y Título
plt.title('Cronograma de Desarrollo - SandiStay (V-Model)', fontsize=16, fontweight='bold', pad=20)
plt.xlabel('Línea de Tiempo', fontsize=12, fontweight='bold')
plt.ylabel('Estructura de Desglose de Trabajo (EDT)', fontsize=12, fontweight='bold')

# Cuadrícula para facilitar la lectura
ax.grid(axis='x', linestyle='--', alpha=0.7)
ax.set_axisbelow(True)

# Ajustar márgenes
plt.tight_layout()

# 6. Guardar y mostrar
nombre_salida = 'diagrama_gantt_sandistay.png'
plt.savefig(nombre_salida, dpi=300, bbox_inches='tight')
print(f"¡Éxito! El diagrama se ha guardado como '{nombre_salida}'")
