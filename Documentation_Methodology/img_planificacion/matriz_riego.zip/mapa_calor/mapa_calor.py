import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap

# --- Estilo global ---
plt.rcParams['font.family'] = 'DejaVu Sans'

fig, ax = plt.subplots(figsize=(10, 8))

# --- Matriz de riesgo ---
grid = np.array([
    [0, 0, 1],
    [0, 1, 2],
    [1, 2, 2]
])

# Colores más modernos (tipo dashboard)
cmap = ListedColormap([
    '#66BB6A',  # verde
    '#FFA726',  # naranja
    '#EF5350'   # rojo
])

ax.imshow(grid, cmap=cmap, origin='lower', extent=[0, 3, 0, 3])

# --- Ejes ---
ax.set_xticks([0.5, 1.5, 2.5])
ax.set_xticklabels(['Tolerable', 'Grave', 'Catastrófico'], fontsize=12)

ax.set_yticks([0.5, 1.5, 2.5])
ax.set_yticklabels(['Baja', 'Media', 'Alta'], fontsize=12)

ax.set_xlabel('Impacto', fontsize=13, labelpad=15)
ax.set_ylabel('Probabilidad', fontsize=13, labelpad=15)
ax.set_title('Matriz de Riesgos - SandiStay', fontsize=18, pad=20)

# --- Grid más suave ---
ax.set_xticks(np.arange(0, 4, 1), minor=True)
ax.set_yticks(np.arange(0, 4, 1), minor=True)
ax.grid(which='minor', color='white', linestyle='-', linewidth=2)

# Quitar bordes innecesarios
for spine in ax.spines.values():
    spine.set_visible(False)

ax.tick_params(which='both', length=0)

# --- Riesgos con mejor estilo ---
riesgos = {
    'R01\nEnfermedad': (2.5, 1.5),
    'R02\nSvelte 5': (0.5, 1.5),
    'R03\nCambios Lógica': (1.5, 2.5),
    'R04\nFallo Mock': (1.5, 0.5),
    'R05\nSubestimación': (0.5, 2.5),
    'R06\nCambio Admin': (2.5, 0.5)
}

for texto, (x, y) in riesgos.items():
    ax.text(
        x, y, texto,
        ha='center', va='center',
        fontsize=10,
        color='#212121',
        bbox=dict(
            boxstyle='round,pad=0.4',
            facecolor='white',
            edgecolor='none',
            alpha=0.95
        )
    )

# --- Leyenda manual ---
from matplotlib.patches import Patch

legend_elements = [
    Patch(facecolor='#66BB6A', label='Bajo'),
    Patch(facecolor='#FFA726', label='Medio'),
    Patch(facecolor='#EF5350', label='Alto')
]

ax.legend(
    handles=legend_elements,
    loc='upper right',
    frameon=False
)

# --- Guardar ---
plt.tight_layout()
plt.savefig('matriz_riesgos_pro.png', dpi=300, bbox_inches='tight')
plt.show()
